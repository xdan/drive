 CKEDITOR.plugins.setLang("stat","en",{
	strlen:'chars',
	sel:'selected',
	source:'source',
	words:'words',
 });