CKEDITOR.plugins.setLang("stat","fr",{
 strlen: 'Lettres',
 sel: 'Selection',
 source: 'Source',
 words: 'Mots',
});