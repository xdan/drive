 CKEDITOR.plugins.setLang("stat","ru",{
	strlen:'Символов',
	sel:'Выделено',
	source:'Исходник',
	words:'Слов',
 });